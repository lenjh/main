02/2017 lh
the new version 1.2 of pigiarniq font is NO GOOD in linux.
the dotted seldom shows and bold / regular reversed in some font lists.

-----



Tested on OpenSuse 12.1 KDE4 .
linux mint 19.1 cinnamon.
4/18/2012 Leonard Hill <lenjh@hotmail.com>
2/6/2019 lh

1 & 2 as root user:
 
1) Place fonts in: /usr/share/fonts/truetype/
2) Rename or delete keyboard file "ca"
   in: /usr/share/X11/xkb/symbols/ 
   place new "ca" keyboard file in same location.
 update font cache: fc-cache -fv

3) If you want to switch layouts with the caps-lock as in the "kbdiu" for windows:
   - in KDE4: open the Keyboard settings module (search the menu for keyboard).
    In the advanced tab,
    check the box "Configure keyboard options".
    Check "Key(s) to change layout".
    Check "Caps Lock"

4) In the Layouts tab add "English(US)" variant "Default"
  and add "English(Canada) variant "Inuktitut".
  Probably you should remove "English(Canada)" variant "Default" so the country flags will change on
  the panel notification area.

5) Log out. Log back in.



note: us basic is the very same as Canadian English layout.
      Use LibreOffice Calc for the spreadsheet because ms Office 2010 
      seems to not work right with unicode.

